import sys

#   Function Remove duplicates Lines
def remove_duplicate_lines(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()

    unique_lines = set(lines)

    with open(filename, 'w') as file:
        file.writelines(unique_lines)

# Get the filename in first argument
ip_set_filename = sys.argv[1]

#Delete duplicates lines in ip1.txt or ip2.txt
file_delDup = ip_set_filename
remove_duplicate_lines(file_delDup)