import sys
import os
import random

#   Function extract ip :
def extract_ips(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()
        ips = [line.strip().replace('http://', '').replace('https://', '').replace('/.git', '') for line in lines]
    return ips

#   Fonction save file
def save_ips_to_file(ips, filename):
    with open(filename, 'w') as file:
        file.write('\n'.join(ips))

#   Function remove file
def remove_file(filename):
    try:
        os.remove(filename)
        print(f"File '{filename}' has been successfully removed.")
    except FileNotFoundError:
        print(f"File '{filename}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

#   Function random lines
def random_lines_in_place(input_file):
    with open(input_file, 'r') as f:
        lines = f.readlines()

    # Shuffle the lines randomly
    random.shuffle(lines)

    with open(input_file, 'w') as f:
        f.writelines(lines)
        
#   Function Remove duplicates Lines
def remove_duplicate_lines(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()

    unique_lines = set(lines)

    with open(filename, 'w') as file:
        file.writelines(unique_lines)

# Get the filename in first argument
ip_set_filename = sys.argv[1]
HistoryIpsGet = sys.argv[2] # HistoryIpsGet = history.txt


# Extract IPs from vulns.txt
history_Ips = extract_ips(HistoryIpsGet)
save_ips_to_file(history_Ips, 'tempHistory.txt')
print("New file tempHistory.txt has bin created")

# Extract IPs from the specified IP set file and Not_vulns.txt
ip_set_ips = set(extract_ips(ip_set_filename))
history_Ips = set(extract_ips('tempHistory.txt'))

# Remove IPs from the specified IP set file that are in tempHistory.txt and Not_vulns.txt
print("Removing ips History in file ",{ip_set_filename},"....")
filtered_ips = [ip for ip in ip_set_ips if ip not in history_Ips]
save_ips_to_file(filtered_ips, ip_set_filename)
print(f"ips History is not in:" ,{ip_set_filename})

#Remove file tempHistory.txt
remove_file("tempHistory.txt")
print("Th file tempHistory has bin deleted")

#Remove file History.txt
remove_file("history.txt")
print("Th file History has bin deleted")
