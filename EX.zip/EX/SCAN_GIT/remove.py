import sys
import os
import random

#   Function extract ip :
def extract_ips(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()
        ips = [line.strip().replace('http://', '').replace('https://', '').replace('/.git', '') for line in lines]
    return ips

#   Fonction save file
def save_ips_to_file(ips, filename):
    with open(filename, 'w') as file:
        file.write('\n'.join(ips))

#   Function remove file
def remove_file(filename):
    try:
        os.remove(filename)
        print(f"File '{filename}' has been successfully removed.")
    except FileNotFoundError:
        print(f"File '{filename}' not found.")
    except Exception as e:
        print(f"An error occurred: {e}")

#   Function random lines
def random_lines_in_place(input_file):
    with open(input_file, 'r') as f:
        lines = f.readlines()

    # Shuffle the lines randomly
    random.shuffle(lines)

    with open(input_file, 'w') as f:
        f.writelines(lines)
        
#   Function Remove duplicates Lines
def remove_duplicate_lines(filename):
    with open(filename, 'r') as file:
        lines = file.readlines()

    unique_lines = set(lines)

    with open(filename, 'w') as file:
        file.writelines(unique_lines)

# Get the filename in first argument
ip_set_filename = sys.argv[1]

#Delete duplicates lines in ip1.txt or ip2.txt
file_delDup = ip_set_filename
remove_duplicate_lines(file_delDup)
print("Duplicate lines removed from", file_delDup)

#Delete duplicates lines in vulns.txt
file_delDup = "vulns.txt"
remove_duplicate_lines(file_delDup)
print("Duplicate lines removed from", file_delDup)

#Delete duplicates lines in Not_vulns.txt
file_delDup = "Not_vulns.txt"
remove_duplicate_lines(file_delDup)
print("Duplicate lines removed from", file_delDup)

# Extract IPs from vulns.txt
vulns_ips = extract_ips('vulns.txt')
save_ips_to_file(vulns_ips, 'tempvulns.txt')
print("New file tempvulns.txt has bin created")

# Extract IPs from the specified IP set file and Not_vulns.txt
ip_set_ips = set(extract_ips(ip_set_filename))
not_vulns_ips = set(extract_ips('Not_vulns.txt'))

# Remove IPs from the specified IP set file that are in tempvulns.txt and Not_vulns.txt
print("Removing ips vulns and not vulns in file ",{ip_set_filename},"....")
filtered_ips = [ip for ip in ip_set_ips if ip not in vulns_ips and ip not in not_vulns_ips]
save_ips_to_file(filtered_ips, ip_set_filename)
print(f"ips vulns and Not_vulns is not in:" ,{ip_set_filename})

#Remove file tempvulns.txt
file_to_remove = "tempvulns.txt"
remove_file(file_to_remove)
print("Th file tempvulns has bin deleted")
# Call the function with your input file name
random_lines_in_place(ip_set_filename)