import os
import telebot
import time

# Telegram Bot API token
TOKEN = '6835107270:AAFeD5uqMSOZlaCwrDcs1BznqQMmU-2htfY'

# Initialize the bot
bot = telebot.TeleBot(TOKEN)

# Directory containing .zip files
directory = '/root/EX/SCAN_GIT'

# Function to send .zip files to Telegram
def send_zip_files(directory, chat_id):
    # List all files in the directory
    files = os.listdir(directory)
    # Filter only .zip files
    zip_files = [f for f in files if f.endswith('.zip')]
    # Iterate over each .zip file and send it
    for zip_file in zip_files:
        retry_count = 3  # Number of retries
        while retry_count > 0:
            try:
                with open(os.path.join(directory, zip_file), 'rb') as f:
                    bot.send_document(chat_id, f)
                print(f"Successfully sent {zip_file} to Telegram")
                break  # Exit loop if sent successfully
            except Exception as e:
                print(f"Error sending {zip_file}:", e)
                retry_count -= 1
                print(f"Retrying {retry_count} more times...")
                time.sleep(5)  # Wait for a moment before retrying
        if retry_count == 0:
            print(f"Failed to send {zip_file} after multiple attempts.")

# Main function
def main():
    # Chat ID where you want to send the files
    chat_id = '-4141694859'
    send_zip_files(directory, chat_id)

if __name__ == "__main__":
    main()
