#!/bin/bash
kill -9 $(ps aux | grep "git" | awk '{print $2}' | tr '\n' ' ')
kill -9 $(ps aux | grep "dump" | awk '{print $2}' | tr '\n' ' ')
sudo rm -r Sendgrid.txt Sms.txt Smtp.txt Pay-api.txt BTC_key.txt Mailgun_key.txt Twilio.txt Aws.txt lola* nohup.out tmp/ envz/
echo "done"
