# Mess-SMTP-Checker
MASS  SMTP VALID INVALID CHECKER

<a href="https://prnt.sc/S-YtDHYzlH80"><img src="https://img001.prntscr.com/file/img001/aJhfhGnpTpi2hcQHI-6hww.png" alt="Mass_smtp-checker" border="0" /></a>
<a href="https://prnt.sc/O4D7kprjcWP9"><img src="https://img001.prntscr.com/file/img001/ahieTpSIQre_psb_WD9-yQ.png" alt="Mass_smtp-checker" border="0" /></a>

- [ ] Install PYTHON 3

# Linux
```
pip3 install -r requirement.txt
```
```
pyhton3 main.py
```
# Windows
```
pip install -r requirement.txt
```
```
main.py
```
