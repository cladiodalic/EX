import os
import asyncio
import time
import datetime
from datetime import datetime
import zipfile
from telegram import Bot
from telegram import InputFile

TOKEN = '6700008488:AAGnOojgry1jQtI3F_5KLb91Z-7os7NAOA4'
CHAT_ID = '-4165737072'
EX_DIRECTORY = '/root/EX'
    
def print_current_date():
    current_date = datetime.date.today()
    print(current_date)


async def send_zip_files(filename):
    # Get a list of all .txt files in the EX directory
    txt_files = [f for f in os.listdir(EX_DIRECTORY) if f.endswith('.txt')]

    # Create a zip file with the specified filename
    zip_filename = f'/tmp/{filename}.zip'
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zipf:
        for txt_file in txt_files:
            file_path = os.path.join(EX_DIRECTORY, txt_file)
            zipf.write(file_path, os.path.basename(file_path))

    # Send the zip file to Telegram
    bot = Bot(token=TOKEN)
    with open(zip_filename, 'rb') as f:
        await bot.send_document(chat_id=CHAT_ID, document=InputFile(f))
        
    # Clean up the temporary zip file
    os.remove(zip_filename)
    print("I send file",user_defined_filename,".zip in Telegram on date: ",datetime.now())

async def main(filename):
    while True:
        await send_zip_files(filename)
        await asyncio.sleep(900)  # Sleep for 15 minutes (900 seconds)

if __name__ == "__main__":
    user_defined_filename = input("Enter file name zip (number server) :")
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main(user_defined_filename))
    print(print_current_date())